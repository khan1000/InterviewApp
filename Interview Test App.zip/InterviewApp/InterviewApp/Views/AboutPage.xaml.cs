﻿using Xamarin.Forms;
using MvvmHelpers;
using InterviewApp.ViewModels;

namespace InterviewApp.Views
{
    public partial class AboutPage : ContentPage
    {
        public AboutPage()
        {
            InitializeComponent();
        }
    }
}