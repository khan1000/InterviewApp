﻿namespace InterviewApp.Interfaces
{
    public interface IPlatformService
    {
        string GetPlatformSpecificString();
    }
}
